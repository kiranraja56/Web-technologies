
 function shop(){
    window.open('shop.html')
 }
//   function addToCart(){
//      alert("Added to cart successfully")
//   }
function SET(){
alert("PLEASE SIGN UP TO SUBMIT YOUR FEEDBACK")
}
function FIRE(){
   alert("Your Feedback is submitted successfully ")
}
function BUY(){
   alert("ORDER PLACED");
}