module.exports = {
  projectId: 'x7hqgi',
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },
};
